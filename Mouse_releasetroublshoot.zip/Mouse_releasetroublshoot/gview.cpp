#include "gview.h"
#include <QPainter>
#include <QGraphicsScene>
#include <QPainter>
#include <QPixmap>
#include <QLineEdit>
#include <QGraphicsSceneMouseEvent>


Gview::Gview()
{

}
