#ifndef MYGRAPHICSVIEW_H
#define MYGRAPHICSVIEW_H
#include <QGraphicsView>

#include <QWidget>

class MyGraphicsview : public QGraphicsView
{
    Q_OBJECT
public:
    explicit MyGraphicsview(QWidget *parent = 0);

signals:

public slots:

private:
     QGraphicsScene *scene;

};

#endif // MYGRAPHICSVIEW_H
