#ifndef GVIEW_H
#define GVIEW_H
#include <QPainter>
#include <QGraphicsScene>
#include <QPainter>
#include <QPixmap>
#include <QLineEdit>
#include <QGraphicsSceneMouseEvent>



class Gview
{
public:

};

#endif // GVIEW_H
