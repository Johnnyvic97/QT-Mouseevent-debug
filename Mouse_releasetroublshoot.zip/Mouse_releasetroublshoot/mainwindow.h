#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QPainter>
#include <QGraphicsScene>
#include <QPainter>
#include <QPixmap>
#include <QLineEdit>
#include <QGraphicsSceneMouseEvent>

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
protected:



 public slots:

    void mouseReleaseEvent(QMouseEvent*e);
    void mousePressEvent(QMouseEvent *event);

private:
    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    QGraphicsView *view;
};

#endif // MAINWINDOW_H
